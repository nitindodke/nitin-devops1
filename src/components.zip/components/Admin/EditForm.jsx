import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'

const EditForm = () => {
  return (
    <>
      <Container>
        <Row>
            <Col>
                <h1>Edit form</h1>
            </Col>
        </Row>
      </Container>
    </>
  )
}

export default EditForm
