import React from "react";
import { Col, Container, Row } from "react-bootstrap";

const AdminHome = () => {
  return (
    <>
      <Container>
        <Row>
          <Col>
            <h1>Welcome, Gaon Connect</h1>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default AdminHome;
