import React from 'react';
import '../App.css';

export default function Footer() {
    return (

        <footer className='text-center'>
            <p className='m-0'>© Goan Connect, All rights reserved.</p>
        </footer>
        // <div className='footer' style={{width:'100%',height:'70px',backgroundColor:'#e3f2fd',display:'flex',justifyContent:'center',alignItems:'center', marginTop:'auto'}}>
        //     <div className='text-primary'>© Gomantak, All rights reserved.</div>
        // </div>
    )
}

